package com.quizPortal.quizPortal.dao.Entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.quizPortal.quizPortal.model.BaseTime;
import com.quizPortal.quizPortal.model.Gender;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

@Entity
public class User extends BaseTime {

    @Id
    @GeneratedValue(strategy =GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "VARCHAR(45)", nullable = false)
    private String name;

    @Column(columnDefinition = "VARCHAR(45)", unique = true, nullable = false)
   //@Email(message = "Email cannot be null")
    private String email;

    @JsonIgnore // this is for ignoring "password" in json.
    @Column(columnDefinition = "VARCHAR(45)", nullable = false)
    //@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$" ,message = "Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character: ")
    private String password;

    @Enumerated(EnumType.STRING)
    //@Column(nullable = true)
    private Gender gender;

    @Column(columnDefinition = "VARCHAR(45)")
    private String linkedIn;

    @Column(columnDefinition = "VARCHAR(100)")
    private String hobbies;

    @Column(columnDefinition = "VARCHAR(10)", nullable = false)
    //@Pattern(regexp="^(0|[1-9][0-9]*)$" , message = "Mobile number contain only numbers")
    private String mobile;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public String getLinkedIn() {
        return linkedIn;
    }

    public void setLinkedIn(String linkedIn) {
        this.linkedIn = linkedIn;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

}
