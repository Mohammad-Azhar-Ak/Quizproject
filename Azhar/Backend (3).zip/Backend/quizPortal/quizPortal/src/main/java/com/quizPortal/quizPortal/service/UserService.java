package com.quizPortal.quizPortal.service;

import com.quizPortal.quizPortal.dao.Entities.User;
import com.quizPortal.quizPortal.dao.Entities.UserSession;
import com.quizPortal.quizPortal.model.dto.CreateUserRequest;
import com.quizPortal.quizPortal.model.dto.UpdateUserRequest;

public interface UserService {

    UserSession createUser(CreateUserRequest request);

    User getUser(String token);

    User updateUser(UpdateUserRequest request, String token);

    UserSession userLogin(CreateUserRequest request);

   // void userLogout(String token);
}
