package com.quizPortal.quizPortal.service;


import com.quizPortal.quizPortal.dao.Entities.User;
import com.quizPortal.quizPortal.dao.Entities.UserSession;

public interface UserSessionService {

   UserSession createSession(User user);
   UserSession checkSession(String token);
   void userLogout(String token);
}
