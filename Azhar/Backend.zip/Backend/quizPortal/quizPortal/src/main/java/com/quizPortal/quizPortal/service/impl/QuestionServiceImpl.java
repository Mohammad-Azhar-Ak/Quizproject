package com.quizPortal.quizPortal.service.impl;

import com.quizPortal.quizPortal.dao.Entities.Quiz;
import com.quizPortal.quizPortal.dao.QuestionDao;
import com.quizPortal.quizPortal.dao.QuizDao;
import com.quizPortal.quizPortal.dao.Entities.Question;
import com.quizPortal.quizPortal.model.dto.AfterSubmitResponse;
import com.quizPortal.quizPortal.model.dto.CreateAndUpdateQuestionRequest;
import com.quizPortal.quizPortal.model.dto.SubmitQuestionsRequest;
import com.quizPortal.quizPortal.service.QuestionService;
import com.quizPortal.quizPortal.service.UserSessionService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    QuestionDao questionDao;

    @Autowired
    QuizDao quizDao;

    @Autowired
    UserSessionService userSessionService;


    @Override
    public Question addQuestion(CreateAndUpdateQuestionRequest request, int quizId) {//quiz id ka validation karna h
        Question question= new Question();
        if(StringUtils.isBlank(request.getStatement()))
            throw new IllegalArgumentException("Statement cannot be empty");
        if(request.getAnswer()==null)
            throw new IllegalArgumentException("Answers cannot be null");
        if(request.getAnswer()!=true && request.getAnswer()!=false)
            throw new IllegalArgumentException("Answer must be true/false");

        question.setStatement(request.getStatement());
        // i am using "boolean" if answer will null it automatically to false
        question.setAnswer(request.getAnswer());

        question.setMarks(request.getMarks());

        Quiz quiz = quizDao.getById(quizId);
        question.setQuiz(quiz);
        questionDao.save(question);
        return null;
    }
    //get all question from one quiz
    @Override
    public List<Question> getAllQuestion(int quizId, String token) {
        if(userSessionService.checkSession(token)==null)//active session check karne ke liye lagaya h
            throw new IllegalArgumentException("Access denied");
        return questionDao.findAllByQuizId(quizId);
    }//quiz id ka validation karna h.

    //Submit Quiz
    @Override
    public AfterSubmitResponse submitQuiz(List<SubmitQuestionsRequest> request, String token, int quizId) { //quiz id b aaegi or uska validation b karna h

        if(userSessionService.checkSession(token)==null)
            throw new IllegalArgumentException("Access denied");
        int rightCount=0,wrongCount=0,total_marks=0,marks_scored=0;
        for (SubmitQuestionsRequest listOfAnswer:request){
            int id=listOfAnswer.getId();
            Boolean user_ans= listOfAnswer.getAnswer();
            if(user_ans==null)//ye answer hm quiz me cosider nhi karenge
            {
                continue;
            }
            Question question=questionDao.getById(id);
            boolean saved_ans = question.isAnswer();
            int final_result = Boolean.compare(user_ans,saved_ans);//. equals wala function use kar le..
            if(final_result==0)//both values are equal
            {
                rightCount++;
                marks_scored+=question.getMarks();
            }
            else wrongCount++;

            total_marks+=question.getMarks();
        }
        List<String>list=new ArrayList<>();
        list.add("Number of Wrong Questions " +Integer.toString(wrongCount));
        list.add("Number of Right Questions "+Integer.toString(rightCount));
        list.add("Total Marks of Quiz "+Integer.toString(total_marks));
        list.add("Marks Scored "+Integer.toString(marks_scored));

        AfterSubmitResponse obj = new AfterSubmitResponse(rightCount,wrongCount,total_marks,marks_scored);
        return obj;
    }
}
