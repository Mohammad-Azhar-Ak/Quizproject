package com.quizPortal.quizPortal.dao.Entities;

import com.quizPortal.quizPortal.model.BaseTime;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Quiz extends BaseTime {

    //defining fields
    @Id
    @GeneratedValue(strategy =GenerationType.IDENTITY)
    private int id;

    @Column(columnDefinition = "VARCHAR(45)")
    private String title;

//    @OneToMany(mappedBy = "quiz" , fetch = FetchType.LAZY)
//    private Set<Question> question;

    public void setId(int id) {
        this.id = id;
    }
//
//    public Set<Question> getQuestion() {
//        return question;
//    }
//
//    public void setQuestion(Set<Question> question) {
//        this.question = question;
//    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
