package com.quizPortal.quizPortal.model;

public enum Gender {
    M,
    F,
    O
}
