package com.quizPortal.quizPortal.service;

import com.quizPortal.quizPortal.dao.Entities.User;
import com.quizPortal.quizPortal.dao.Entities.UserSession;
import com.quizPortal.quizPortal.model.dto.CreateUserRequest;
import com.quizPortal.quizPortal.model.dto.LoginSignupResponse;
import com.quizPortal.quizPortal.model.dto.UpdateUserRequest;

public interface UserService {

    LoginSignupResponse createUser(CreateUserRequest request);

    User getUser(String token);

    User updateUser(UpdateUserRequest request, String token);

    LoginSignupResponse userLogin(CreateUserRequest request);

   // void userLogout(String token);
}
