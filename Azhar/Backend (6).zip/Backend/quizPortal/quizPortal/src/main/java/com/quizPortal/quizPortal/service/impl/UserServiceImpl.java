package com.quizPortal.quizPortal.service.impl;

import com.quizPortal.quizPortal.dao.Entities.User;
import com.quizPortal.quizPortal.dao.Entities.UserSession;
import com.quizPortal.quizPortal.dao.UserSessionDao;
import com.quizPortal.quizPortal.model.Gender;
import com.quizPortal.quizPortal.model.dto.CreateUserRequest;
import com.quizPortal.quizPortal.model.dto.LoginSignupResponse;
import com.quizPortal.quizPortal.model.dto.UpdateUserRequest;
import com.quizPortal.quizPortal.service.UserService;
import com.quizPortal.quizPortal.service.UserSessionService;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.quizPortal.quizPortal.dao.UserDao;

@Service
public class UserServiceImpl implements UserService {



    @Autowired
    UserDao userDao;

    @Autowired
    UserSessionService userSessionService;

    @Autowired
    UserSessionDao userSessionDao;


    //for user signup with login.
    @Override
    public LoginSignupResponse createUser(CreateUserRequest request) {
        if(StringUtils.isBlank(request.getEmail()))
            throw new IllegalArgumentException("Unauthorized User");
        if(StringUtils.isBlank(request.getName()))
            throw new IllegalArgumentException("Unauthorized User");
        if(StringUtils.isBlank(request.getPassword()))
            throw new IllegalArgumentException("Unauthorized User");
        if(StringUtils.isBlank(request.getMobile()))
            throw new IllegalArgumentException("Unauthorized User");
        if(!request.getEmail().matches("^([\\w-\\.]+){1,64}@([\\w&&[^_]]+){2,255}.[a-z]{2,}$"))
            throw new IllegalArgumentException("Invalid Email");
        if(!request.getPassword().matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"))
            throw new IllegalArgumentException("Please enter a valid password having atleast a digit," +
                    " a lowercase character, an uppercase character," +
                    " a special character and should be of minimum length 8 without any space.");
        if (!request.getMobile().matches("\\d{10}"))
            throw new IllegalArgumentException("Invalid Mobile Number");
        if (userDao.findByEmail(request.getEmail()) != null)
            throw new IllegalArgumentException("User with this email already exists.");
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setMobile(request.getMobile());
        userDao.save(user);
        UserSession userSession = userSessionService.createSession(user);
        LoginSignupResponse loginSignupResponse = new LoginSignupResponse(userSession.getToken(), user.getName());
        return loginSignupResponse;
    }


    //GET a single user of given token.
    @Override
    public User getUser(String token) {
        if(StringUtils.isBlank(token))
            throw new IllegalArgumentException("Unauthorized User");
        UserSession userSession = userSessionDao.findByToken(token);
        if(userSession==null || userSession.getSignOutTime()==null)
            throw new IllegalArgumentException("Unauthorized User, Login Again");//Access denied
        User user = userSession.getUser();
        if(user==null)
            throw new IllegalArgumentException("Unauthorized User, Login Again");//Access denied
        return user;
    }

    //for updating profile of user
    @Override
    public User updateUser(UpdateUserRequest request, String token) {
        if(StringUtils.isBlank(token))
            throw new IllegalArgumentException("Unauthorized User");
        if(StringUtils.isBlank(request.getName()))
            throw new IllegalArgumentException("Unauthorized User");
        if(StringUtils.isBlank(request.getMobile()))
            throw new IllegalArgumentException("Unauthorized User");
        if (!request.getMobile().matches("\\d{10}"))
            throw new IllegalArgumentException("Please enter a valid mobile number.");
        UserSession userSession = userSessionDao.findByToken(token);
        if(userSession==null)
            throw new IllegalArgumentException("Unauthorized User, Login Again");//Access denied
        User user = userSession.getUser();
        if(user == null)
            throw new IllegalArgumentException("User Not Exist");
        user.setName(request.getName());
        user.setMobile(request.getMobile());
        user.setHobbies(request.getHobbies());
        user.setLinkedIn(request.getLinkedIn());
        user.setGender(request.getGender());//isko kaise verify kare ye bata dijiye
        return userDao.save(user);
    }

    //for Login functionality
    @Override
    public LoginSignupResponse userLogin(CreateUserRequest request) {
        if(StringUtils.isBlank(request.getEmail()))
            throw new IllegalArgumentException("Unauthorized User");
        if(StringUtils.isBlank(request.getPassword()))
            throw new IllegalArgumentException("Unauthorized User");
        User user = userDao.findByEmail(request.getEmail());
        if(user==null)
           throw new IllegalArgumentException("User Not Registered");
        if(!user.getPassword().equals(request.getPassword()))
            throw new IllegalArgumentException("Invalid Credentials");
        UserSession userSession = userSessionService.createSession(user);
        LoginSignupResponse loginSignupRespons =new LoginSignupResponse(userSession.getToken(),user.getName());
        return loginSignupRespons;


    }
}
