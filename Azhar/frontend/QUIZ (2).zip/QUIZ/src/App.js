import Navigation from './navigation'

function App() {
  return (
    <Navigation />
  );
}

export default App;