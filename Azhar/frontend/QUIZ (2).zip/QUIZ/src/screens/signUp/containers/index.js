import SingUpContainer from './SignUp'

export {
    SingUpContainer
}