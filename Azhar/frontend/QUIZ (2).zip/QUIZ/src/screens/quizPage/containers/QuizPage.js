import React, { Component } from 'react'
import { QuizPageComponent } from '../components';

class QuizPageContainer extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <QuizPageComponent />
        )

    }
}

export default QuizPageContainer