import { QuizPageContainer as QuizPage } from './containers'

export default QuizPage