import React, { Component } from 'react'
import { ProfileComponent } from '../components';

class ProfileContainer extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <ProfileComponent />
        )

    }
}

export default ProfileContainer