import { ProfileContainer as Profile } from "./containers";

export default Profile