const gender = [
    { value: "M", label: "Male" },
    { value: "F", label: "Female" },
    { value: "O", label: "Others" }];

const choice = [
    { value: "true", label: "True" },
    { value: "false", label: "False" }

]

export {
    gender,
    choice
}