const CustomLogo = require('./signin.jpg')
const SignUpImg = require('./signup.jpg')

export{
    CustomLogo,
    SignUpImg
}