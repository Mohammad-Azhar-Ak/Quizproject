import React from 'react'


const HeaderComponent = ({ }) => {
    return (
       <header>this is header</header>
    )
}

export default HeaderComponent