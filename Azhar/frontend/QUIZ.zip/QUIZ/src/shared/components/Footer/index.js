import React from 'react';

const NewFooter = ({ }) => {
    return (
       <h3>this is footer</h3>
    )
}

export default NewFooter;