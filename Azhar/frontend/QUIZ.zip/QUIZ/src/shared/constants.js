export const gender = [
    { value: "M", label: "Male" },
    { value: "F", abel: "Female" }];