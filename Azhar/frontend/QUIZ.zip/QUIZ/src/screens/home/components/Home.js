import React, { Fragment } from 'react'

const HomeComponent = ({ }) => {
    return (
        <Fragment>
            <h1 style={{ color: 'green' }}>Welcome to Home Page</h1>
        </Fragment>
    )
}

export default HomeComponent