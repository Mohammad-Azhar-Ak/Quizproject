import QuizPageComponent from './QuizPage'

export {
    QuizPageComponent
}