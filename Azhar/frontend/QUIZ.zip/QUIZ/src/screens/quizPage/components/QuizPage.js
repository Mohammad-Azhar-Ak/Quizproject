import React, { Fragment } from 'react'

const QuizPageComponent = ({ }) => {
    return (
        <Fragment>
            <h1 style={{ color: 'green' }}>Welcome to Quiz Page</h1>
        </Fragment>
    )
}

export default QuizPageComponent