import React, { Fragment } from 'react'

const ProfileComponent = ({ }) => {
    return (
        <Fragment>
            <h1 style={{ color: 'green' }}>Profile Page</h1>
        </Fragment>
    )
}

export default ProfileComponent