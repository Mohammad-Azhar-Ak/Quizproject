import ProfileComponent from './Profile'

export{
    ProfileComponent
}