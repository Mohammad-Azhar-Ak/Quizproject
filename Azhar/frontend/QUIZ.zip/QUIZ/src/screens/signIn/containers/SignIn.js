import React, { Component } from 'react'
import { SignInComponent } from '../components';

class SignInContainer extends Component {

    constructor() {
        super()
    }

    render() {
        return (
            <SignInComponent />
        )

    }
}

export default SignInContainer