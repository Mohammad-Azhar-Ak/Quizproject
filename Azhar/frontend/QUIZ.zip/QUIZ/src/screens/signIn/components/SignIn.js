import React from 'react'


const SignInComponent = () => {
    return (
        <h1>SignInPage</h1>
    )
}


export default SignInComponent