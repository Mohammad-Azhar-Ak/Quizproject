import { SingInContainer as SignIn } from './containers'

export default SignIn