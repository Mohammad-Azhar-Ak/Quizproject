import React, { Component } from 'react'
import { SignUpComponent } from '../components';

class SignUpContainer extends Component {

    constructor() {
        super()
    }

    render() {
        return (
            <SignUpComponent />
        )

    }
}

export default SignUpContainer