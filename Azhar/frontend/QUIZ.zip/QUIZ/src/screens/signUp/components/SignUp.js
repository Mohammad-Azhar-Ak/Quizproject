import React from 'react'


const SignUpComponent = () => {
    return (
        <h1>SignUpPage</h1>
    )
}


export default SignUpComponent