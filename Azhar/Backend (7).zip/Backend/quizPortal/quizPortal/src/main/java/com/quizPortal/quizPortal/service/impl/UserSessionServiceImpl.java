package com.quizPortal.quizPortal.service.impl;

import com.quizPortal.quizPortal.dao.Entities.User;
import com.quizPortal.quizPortal.dao.Entities.UserSession;
import com.quizPortal.quizPortal.dao.UserSessionDao;
import com.quizPortal.quizPortal.service.UserSessionService;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.file.AccessDeniedException;
import java.util.Date;

@Service
public class UserSessionServiceImpl implements UserSessionService {
    @Autowired
    UserSessionDao userSessionDao;

    @Override
    public UserSession createSession(User user) {

        //UserSession part is here
        UserSession userSession = new UserSession();
        while(true) {
            String userToken = RandomStringUtils.randomAlphanumeric(45).toUpperCase();//isme rishabh bhai ka function lagana h.
            if (userSessionDao.findByToken(userToken)==null) {   //Unique token will be created
                userSession.setToken(userToken);
                break;
            }
        }
        userSession.setSignInTime(new Date());
        userSession.setUser(user);
        return userSessionDao.save(userSession);
    }

    @Override
    public UserSession checkSession(String token) {
        UserSession userSession=userSessionDao.findByToken(token);
        if(userSession==null || userSession.getSignOutTime()!=null)
            throw new IllegalArgumentException("Access denied, please signin again");
        return userSession;
    }

    @Override
    public void userLogout(String token) {
        UserSession loginUser = userSessionDao.findByToken(token);
        if(loginUser==null)
            throw new IllegalArgumentException("Invalid user");
        if (loginUser.getSignOutTime() == null) {
            loginUser.setSignOutTime(new Date());
            userSessionDao.save(loginUser);
        }
        else
            throw new IllegalArgumentException("User Already logout");//Access denied kaise lagae.
    }
}
