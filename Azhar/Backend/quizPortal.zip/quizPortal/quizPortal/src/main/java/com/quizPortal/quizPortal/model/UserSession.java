package com.quizPortal.quizPortal.model;

import javax.persistence.*;

import java.util.Date;

@Entity
public class UserSession {

    @Id
    @GeneratedValue
    private int id;

    @Column(columnDefinition = "VARCHAR(45)", nullable = false)
    private String token;

    @Column(columnDefinition = "DATETIME", nullable = false)
    private Date signInTime;

    @Column(columnDefinition = "DATETIME")
    private Date signOutTime;

    @ManyToOne
    @JoinColumn(name = "user_id" )
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getSignInTime() {
        return signInTime;
    }

    public void setSignInTime(Date signInTime) {
        this.signInTime = signInTime;
    }

    public Date getSignOutTime() {
        return signOutTime;
    }

    public void setSignOutTime(Date signOutTime) {
        this.signOutTime = signOutTime;
    }
}
