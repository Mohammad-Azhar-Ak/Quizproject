package com.quizPortal.quizPortal.service.impl;

import com.quizPortal.quizPortal.dao.QuestionDao;
import com.quizPortal.quizPortal.model.Question;
import com.quizPortal.quizPortal.model.dto.CreateAndUpdateQuestionRequest;
import com.quizPortal.quizPortal.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class QuestionServiceImpl implements QuestionService {

    @Autowired
    QuestionDao questionDao;

    Question question = new Question();
    @Override
    public void setQuestionList(List<Question> question) {
        for(Question i:question)
        {
            questionDao.save(i);
        }
    }

    @Override
    public List<Question> takeAllQuestion(CreateAndUpdateQuestionRequest request, int quizId) {
        question.setStatement(request.getStatement());
        question.setAnswer(request.getAnswer());
        question.setMarks(request.getMarks());

        return null;
    }
}
