package com.quizPortal.quizPortal.model;

import javax.persistence.*;

import java.util.Date;
import java.util.List;


@Entity
public class Quiz {

    //defining fields
    @Id
    @GeneratedValue
    private int id;

    @Column(columnDefinition = "VARCHAR(45)")
    private String title;

    @Column(columnDefinition = "DATETIME")
    private Date createdTIme;

    @Column(columnDefinition = "DATETIME")
    private Date updatedTime;

    @OneToMany(mappedBy = "quiz")
    private List<Question> questions;

    //defining getter and setter


    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getCreatedTIme() {
        return createdTIme;
    }

    public void setCreatedTIme(Date createdTIme) {
        this.createdTIme = createdTIme;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }
}
