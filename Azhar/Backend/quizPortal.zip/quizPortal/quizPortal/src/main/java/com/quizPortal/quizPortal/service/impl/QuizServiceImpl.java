package com.quizPortal.quizPortal.service.impl;


import com.quizPortal.quizPortal.dao.QuestionDao;
import com.quizPortal.quizPortal.dao.QuizDao;
import com.quizPortal.quizPortal.model.Question;
import com.quizPortal.quizPortal.model.Quiz;
import com.quizPortal.quizPortal.model.dto.CreateUpdateQuizRequest;
import com.quizPortal.quizPortal.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class QuizServiceImpl implements QuizService {

    @Autowired
    QuizDao quizDao;

    @Autowired
    QuestionDao questionDao;



    @Override
    public Quiz createQuiz(CreateUpdateQuizRequest request) {
        Quiz quiz = new Quiz();
        quiz.setId(request.getId());
        quiz.setTitle(request.getTitle());
        quiz.setCreatedTIme(new Date());
        quiz.setUpdatedTime(new Date());

        return quizDao.save(quiz);

    }

    @Override
    public Quiz getQuiz(int quizId) {
        return quizDao.findById(quizId).orElse(null);
    }

    @Override
    public List<Quiz> getAllQuiz() {


        return quizDao.findAll();
    }
}
