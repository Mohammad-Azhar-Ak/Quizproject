package com.quizPortal.quizPortal.model.dto;

import com.quizPortal.quizPortal.model.Question;

import java.util.Date;
import java.util.List;

public class CreateUpdateQuizRequest {
    private int id;
    private String title;
    private Date createdTime;
    private Date updatedTime;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }
}
