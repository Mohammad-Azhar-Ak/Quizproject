package com.quizPortal.quizPortal.service;

import com.quizPortal.quizPortal.model.User;
import com.quizPortal.quizPortal.model.UserSession;
import com.quizPortal.quizPortal.model.dto.CreateUpdateUserRequest;

public interface UserService {

    UserSession createUser(CreateUpdateUserRequest request);

    User getUser(int userId);

    User updateUser(CreateUpdateUserRequest request, int userId);

    UserSession userLogin(CreateUpdateUserRequest request);

    void userLogout(String token);
}
