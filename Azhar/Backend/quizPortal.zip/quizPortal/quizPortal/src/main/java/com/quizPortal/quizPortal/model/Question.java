package com.quizPortal.quizPortal.model;

import javax.persistence.*;
import java.util.Date;


@Entity
public class Question {

    @Id
    @GeneratedValue
    private int id;

    @Column(columnDefinition = "VARCHAR(200)")
    private String statement;

    private boolean answer;

    private int marks;

    @Column(columnDefinition = "DATETIME")
    private Date createdTime;

    @Column(columnDefinition = "DATETIME")
    private Date updatedTime;

    @ManyToOne
    @JoinColumn(name = "quiz_id", insertable = false , updatable = false)
    private Quiz quiz;

    public Quiz getQuiz() {
        return quiz;
    }

    public void setQuiz(Quiz quiz) {
        this.quiz = quiz;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatement() {
        return statement;
    }

    public void setStatement(String statement) {
        this.statement = statement;
    }

    public boolean isAnswer() {
        return answer;
    }

    public void setAnswer(boolean answer) {
        this.answer = answer;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }
}
