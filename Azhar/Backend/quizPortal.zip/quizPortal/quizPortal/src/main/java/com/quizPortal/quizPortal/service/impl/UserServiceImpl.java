package com.quizPortal.quizPortal.service.impl;

import com.quizPortal.quizPortal.model.User;
import com.quizPortal.quizPortal.model.UserSession;
import com.quizPortal.quizPortal.model.dto.CreateUpdateUserRequest;
import com.quizPortal.quizPortal.service.UserService;
import com.quizPortal.quizPortal.service.UserSessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.quizPortal.quizPortal.dao.UserDao;
import org.springframework.util.Assert;
import java.util.Date;

@Service
public class UserServiceImpl implements UserService {



    @Autowired
    UserDao userDao;

    @Autowired
    UserSessionService userSessionService;

    User user = new User();

    @Override
    public UserSession createUser(CreateUpdateUserRequest request) {

        Assert.isTrue(request.getMobile().length() == 10, "Mobile Number must be of 10 digit.");
        //rest of the conditions
        if (userDao.findByEmail(request.getEmail()) != null)
            throw new IllegalArgumentException("User with this email already exists.");

        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setMobile(request.getMobile());
        user.setGender(request.getGender());
        user.setLinkedIn(request.getLinkedIn());
        user.setHobbies(request.getHobbies());
        user.setCreatedTime(request.getCreatedTime());
        user.setUpdatedTime(request.getUpdatedTime());
        userDao.save(user);

        return userSessionService.createSession(user);
    }



    @Override
    public User getUser(int userId) {

        return userDao.findById(userId).orElse(null);
    }

    @Override
    public User updateUser(CreateUpdateUserRequest request, int userId) {
        User user = userDao.findById(userId).orElse(null);
        if(user == null)
        {
            new Exception("User Not Exist");
        }
        Assert.isTrue(request.getMobile().length() == 10, "Mobile Number must be of 10 digit.");
        user.setName(request.getName());
        user.setMobile(request.getMobile());
        user.setHobbies(request.getHobbies());
        user.setLinkedIn(request.getLinkedIn());
        user.setGender(request.getGender());
        user.setUpdatedTime(new Date());
        request.getUpdatedTime();
        return userDao.save(user);
    }

    @Override
    public UserSession userLogin(CreateUpdateUserRequest request) {

       if(userDao.findByEmail(request.getEmail())==null)
       {
           throw new RuntimeException("User Not Registered");
       }
       if(userDao.findByEmail(request.getEmail()).getPassword().equals(request.getPassword()))
       {
           User user = userDao.findByEmail(request.getEmail());
           return userSessionService.createSession(user);
       }
       else
           throw new RuntimeException("Wrong Password");


    }

    @Override
    public void userLogout(String token) {
        userSessionService.userLogout(token);
    }
}
