package com.quizPortal.quizPortal.service.impl;

import com.quizPortal.quizPortal.dao.UserSessionDao;
import com.quizPortal.quizPortal.model.User;
import com.quizPortal.quizPortal.model.UserSession;
import com.quizPortal.quizPortal.service.UserSessionService;
import com.quizPortal.quizPortal.tokenGenerator.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserSessionServiceImpl implements UserSessionService {
    @Autowired
    UserSessionDao userSessionDao;

    @Override
    public UserSession createSession(User user) {

        //Generating Token
        Token token = new Token();

        //UserSession part is here
        UserSession userSession = new UserSession();
        userSession.setSignInTime(user.getCreatedTime());
        userSession.setToken(token.getAlphaNumericString());
        userSession.setUser(user);
        return userSessionDao.save(userSession);
    }

    @Override
    public void userLogout(String token) {
        UserSession loginUser=userSessionDao.findByToken(token);
        if(loginUser.getSignOutTime()==null) {
            loginUser.setSignOutTime(new Date());
            userSessionDao.save(loginUser);
        }
        else
            throw new RuntimeException("User already logout");
    }
}
