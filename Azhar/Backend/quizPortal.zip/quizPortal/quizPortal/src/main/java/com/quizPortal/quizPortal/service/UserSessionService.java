package com.quizPortal.quizPortal.service;

import com.quizPortal.quizPortal.model.User;
import com.quizPortal.quizPortal.model.UserSession;


public interface UserSessionService {

   UserSession createSession(User user);


   void userLogout(String token);
}
