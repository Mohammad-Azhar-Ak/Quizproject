package com.quizPortal.quizPortal.controller;

import com.quizPortal.quizPortal.model.Question;
import com.quizPortal.quizPortal.model.dto.CreateAndUpdateQuestionRequest;
import com.quizPortal.quizPortal.model.dto.CreateUpdateQuizRequest;
import com.quizPortal.quizPortal.service.QuestionService;
import com.quizPortal.quizPortal.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.quizPortal.quizPortal.model.Quiz;

import java.util.List;

@RestController
@RequestMapping(path = "/quiz")
public class QuizController {

    @Autowired
    QuizService quizService;

    @Autowired
    QuestionService questionService;

    @PostMapping
    public Quiz createQuiz(@RequestBody CreateUpdateQuizRequest request){
        Quiz quiz=quizService.createQuiz(request);
        return quiz;
    }

    @GetMapping(path="/{quizId}")
    public Quiz getQuiz(@PathVariable("quizId") int quizId){
        Quiz quiz = quizService.getQuiz(quizId);
        return quiz;
    }

    @GetMapping
    public List<Quiz> getAllQuiz(){
        return quizService.getAllQuiz();
    }

    @PostMapping(path ="/{quizId}")
    public List<Question> takeAllQuestion(@RequestBody CreateAndUpdateQuestionRequest request, @PathVariable("quizId") int quizId)
    {
        return questionService.takeAllQuestion(request,quizId);
    }
}
