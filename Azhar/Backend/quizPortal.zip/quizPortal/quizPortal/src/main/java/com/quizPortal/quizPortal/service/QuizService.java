package com.quizPortal.quizPortal.service;

import com.quizPortal.quizPortal.model.Quiz;
import com.quizPortal.quizPortal.model.dto.CreateUpdateQuizRequest;

import java.util.List;

public interface QuizService {
    Quiz createQuiz(CreateUpdateQuizRequest request);
    Quiz getQuiz(int quizId);
    List<Quiz> getAllQuiz();
}
