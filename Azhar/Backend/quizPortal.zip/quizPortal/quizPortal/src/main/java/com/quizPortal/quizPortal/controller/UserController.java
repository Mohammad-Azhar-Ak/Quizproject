package com.quizPortal.quizPortal.controller;

import com.quizPortal.quizPortal.model.User;
import com.quizPortal.quizPortal.model.UserSession;
import com.quizPortal.quizPortal.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.quizPortal.quizPortal.model.dto.CreateUpdateUserRequest;

@RestController
@RequestMapping(path="/user")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping
    public UserSession createUser(@RequestBody CreateUpdateUserRequest request){
        UserSession user = userService.createUser(request);
        return user;
    }
    @GetMapping(path = "/{userId}")
    public User getUser(@PathVariable("userId") int userId){
        User user = userService.getUser(userId);
        return user;
    }

    @PostMapping(path = "/{userId}")
    public User updateUser(@RequestBody CreateUpdateUserRequest request,@PathVariable("userId") int userId){
        User user = userService.updateUser(request,userId);
        return user;
    }

    @PostMapping(path = "/login")
    public UserSession userLogin(@RequestBody CreateUpdateUserRequest request){
        UserSession userSession = userService.userLogin(request);
        return userSession;
    }

    @PostMapping(path ="/logout/{token}")
    public void userLogout(@PathVariable("token") String token){
        userService.userLogout(token);
    }

}
