package com.quizPortal.quizPortal.model.dto;


import com.quizPortal.quizPortal.model.UserSession;

import java.util.Date;
import java.util.Set;


public class CreateUpdateUserRequest {

    private int id;
    private String name;
    private String email;
    private String password;
    private char gender;
    private String linkedIn;
    private String hobbies;
    private String mobile;
    private Date createdTime;
    private Date updatedTime;
//    private Set<UserSession> userSession;
//
//    public Set<UserSession> getUserSession() {
//        return userSession;
//    }
//
//    public void setUserSession(Set<UserSession> userSession) {
//        this.userSession = userSession;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getLinkedIn() {
        return linkedIn;
    }

    public void setLinkedIn(String linkedIn) {
        this.linkedIn = linkedIn;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }
}
