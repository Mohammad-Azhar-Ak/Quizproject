package com.quizPortal.quizPortal.model;


import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name="User")
public class User {

    // define fields of tables
    @Id
    @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(columnDefinition = "VARCHAR(45)", nullable = false)
    private String name;

    @Column(columnDefinition = "VARCHAR(45)", unique = true)
    private String email;

    @Column(columnDefinition = "VARCHAR(45)", nullable = false)
    private String password;

    private char gender;

    @Column(columnDefinition = "VARCHAR(45)")
    private String linkedIn;

    @Column(columnDefinition = "VARCHAR(100)")
    private String hobbies;

    @Column(columnDefinition = "VARCHAR(10)", nullable = false)
    private String mobile;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    private Date createdTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    private Date updatedTime;

    @PrePersist
    private void onCreate()
    {
        createdTime = new Date();
        updatedTime = new Date();
    }



//    @OneToMany(mappedBy = "user")
//    private Set<UserSession> userSession;

//    public Set<UserSession> getUserSession() {
//        return userSession;
//    }
//
//    public void setUserSession(Set<UserSession> userSession) {
//        this.userSession = userSession;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public char getGender(char gender) {
        return this.gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getLinkedIn() {
        return linkedIn;
    }

    public void setLinkedIn(String linkedIn) {
        this.linkedIn = linkedIn;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime =updatedTime ;
    }
}
