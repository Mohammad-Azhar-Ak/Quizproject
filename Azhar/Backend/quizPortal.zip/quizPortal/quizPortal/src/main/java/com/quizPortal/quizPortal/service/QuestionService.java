package com.quizPortal.quizPortal.service;

import com.quizPortal.quizPortal.model.Question;
import com.quizPortal.quizPortal.model.dto.CreateAndUpdateQuestionRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface QuestionService {

    void setQuestionList(List<Question> question);
    List<Question> takeAllQuestion(CreateAndUpdateQuestionRequest request, int quizId);
}
