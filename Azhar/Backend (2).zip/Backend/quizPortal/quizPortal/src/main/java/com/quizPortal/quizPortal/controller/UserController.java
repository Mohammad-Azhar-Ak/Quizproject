package com.quizPortal.quizPortal.controller;

import com.quizPortal.quizPortal.dao.Entities.User;
import com.quizPortal.quizPortal.dao.Entities.UserSession;
import com.quizPortal.quizPortal.model.dto.BaseResponse;
import com.quizPortal.quizPortal.model.dto.CreateUserRequest;
import com.quizPortal.quizPortal.model.dto.UpdateUserRequest;
import com.quizPortal.quizPortal.service.UserService;;
import com.quizPortal.quizPortal.service.UserSessionService;
import org.apache.catalina.authenticator.BasicAuthenticator;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.websocket.AuthenticationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.AccessDeniedException;

@RestController
@RequestMapping(path="/user")
public class UserController {

    @Autowired
    UserService userService;

    @Autowired
    UserSessionService userSessionService;

    //for creating user
    @PostMapping
    public BaseResponse<UserSession> createUser(@RequestBody CreateUserRequest request){
        UserSession user = userService.createUser(request);
        return new BaseResponse<>(HttpStatus.OK.value(), "Success", user);
    }

    //for user login
    @PostMapping(path = "/login")
    public BaseResponse<UserSession> userLogin(@RequestBody CreateUserRequest request){
        UserSession userSession = userService.userLogin(request);
        return new BaseResponse<>(HttpStatus.OK.value(), "Success", userSession);
    }

    //for getting single user
    @GetMapping(path = "/profile")
    public BaseResponse<User> getUser(@RequestHeader("Authorization")String token){
        if(StringUtils.isBlank(token))
            throw new RuntimeException("Access Denied");
        User user = userService.getUser(token);
        return new BaseResponse<>(HttpStatus.OK.value(), "Success", user);
    }

    //for user update profile
    @PostMapping(path = "/update")
    public BaseResponse<User> updateUser(@RequestHeader("Authorization") String token,@RequestBody UpdateUserRequest request){
        if(StringUtils.isBlank(token))
            throw new RuntimeException("Access Denied");
        User user =userService.updateUser(request,token);
        return new BaseResponse<>(HttpStatus.OK.value(), "Success", user);
    }

    //for logout user
    @PostMapping(path ="/logout")
    public BaseResponse<User> userLogout(@RequestHeader("Authorization") String token) {
        if(StringUtils.isBlank(token))
            throw new RuntimeException("Access Denied");
        userSessionService.userLogout(token);
        return new BaseResponse<>(HttpStatus.OK.value(), "User successfully logout.");//isko puchna h isme data: null extra aa raha h
    }
}
